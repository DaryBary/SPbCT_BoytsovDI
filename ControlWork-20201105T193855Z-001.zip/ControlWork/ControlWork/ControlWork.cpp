﻿#define _CRT_SECURE_NO_WARNINGS
#include <process.h>
#include <stdarg.h>
#include <string.h>
#include <iostream>


using namespace std;

int main(int argc, char* argv[])
{
    setlocale(LC_ALL, "ru");
    FILE* file = fopen(argv[1], "r");
    char* pEnd;
    char chrs[100];
    int count = -1, 
    max = strtoll(argv[2], &pEnd, 10);
    cout << "Выбранный файл:\n";
    while (true)
    {
        count++;
        chrs[count] = fgetc(file);
        if (chrs[count] == EOF)
            break;
        cout << chrs[count] << " ";
    }
    fclose(file);
    file = fopen(argv[1], "w");
    cout << "\nНовый файл:\n";
    for (int i = 0; i < count; i++) {
        if (i == max) {
            fprintf(file, "B");
            cout << "B ";
        }
        fprintf(file, "%c", chrs[i]);
        cout << chrs[i] << " ";
    }
    if (max >= count) {
        fprintf(file, "B");
        cout << "B ";
    }
    fclose(file);
}
